# -*- coding: utf-8 -*-
"""
Created on Thu Jan 16 08:16:15 2020

@author: Administrateur
"""
import numpy as np
import matplotlib.pyplot as plt

# Ouverture du fichier de coordonnées du point B
fichier=open('Point_C.txt','r')
contenu=fichier.read()
fichier.close()
lignes=contenu.split('\n')

# La fonction data_gen extrait les données t, x, y du fichier de coordonnées
def data_gen(lignes):
    t=[]
    x=[]
    y=[]
    t0=1.631
    for ligne in lignes[2:-1]:
        data=ligne.replace(',','.').split('\t')
        if float(data[0])>t0:
            t.append(float(data[0])-t0)
            y.append(-float(data[1]))
            x.append(float(data[2]))
    return np.array(t),np.array(x),np.array(y)        

t,xC,yC=data_gen(lignes)

xA=np.zeros(len(t))
yA=np.zeros(len(t))

#Régression circulauire, cf doc XXX

# Coordonnées du barycentre
xm = np.mean(xC)
ym = np.mean(yC)

# Calcul des coordonnées réduites
u = xC - xm
v = yC - ym

# Système linéaire qui définit le centre (uc, vc) en coordonnées réduites:
#    Suu * uc +  Suv * vc = (Suuu + Suvv)/2
#    Suv * uc +  Svv * vc = (Suuv + Svvv)/2
Suv  = sum(u*v)
Suu  = sum(u**2)
Svv  = sum(v**2)
Suuv = sum(u**2 * v)
Suvv = sum(u * v**2)
Suuu = sum(u**3)
Svvv = sum(v**3)

# Résolution du système linéaire
A = np.array([ [ Suu, Suv ], [Suv, Svv]])
B = np.array([ Suuu + Suvv, Svvv + Suuv ])/2.0
uc, vc = np.linalg.solve(A, B)

xB = (xm + uc)*np.ones(len(t))
yB = (ym + vc)*np.ones(len(t))

# Calcul des distances au centre (xc_1, yc_1)
lBCi = np.sqrt((xC-xB)**2 + (yC-yB)**2)
lBC = np.mean(lBCi)*np.ones(len(t))
erreur = sum((lBCi-lBC)**2)

# Calcul de lBC du facteur d'échelle
lBC_reel=0.089*np.ones(len(t))
ech=lBC_reel/lBC
ech=ech[0]
lBC=lBC_reel*np.ones(len(t))

# Tracé des trajectoires
theta=np.arange(0,2*np.pi,0.01)
plt.figure('Trajectoires')
plt.axis('equal')
plt.scatter(ech*xC,ech*yC,color='green')
plt.plot(xB[0]*ech+lBC[0]*np.cos(theta),yB[0]*ech+lBC[0]*np.sin(theta))
plt.scatter(xB[0]*ech,yB[0]*ech,color='red')
plt.scatter(0,0,color='orange')

# Calcul des distances lAB et lAC à partir des relevés expérimentaux
lABi = np.sqrt((xA-xB)**2 + (yA-yB)**2)
lAB = np.mean(lABi)*ech
lAC = np.sqrt((xA-xC)**2 + (yA-yC)**2)*ech

# Calcul de theta_1
theta_1=np.arctan((yA-yC)/(xA-xC))
theta_12=[theta_1[0]]
dt=0
im=0
for i,te in enumerate(theta_1[1:]):
    if np.abs(theta_1[i]-te)>1 and np.abs(i-im)!=1:
        im=i
        dt+=np.pi*np.sign(theta_1[i-1]-te)
    theta_12.append(te+dt)
theta_1=np.array(theta_12)

# Tracé de theta_1
plt.figure('Theta_1')
plt.plot(t,theta_1)

# Calcul de theta_2
theta_2=np.arctan((yC-yB)/(xC-xB))
theta_22=[theta_2[0]]
dt=0
im=0
for i,te in enumerate(theta_2[1:]):
    if np.abs(theta_2[i]-te)>1 and np.abs(i-im)!=1:
        im=i
        dt+=np.pi*np.sign(theta_2[i-1]-te)
    theta_22.append(te+dt)
theta_2=np.array(theta_22)
theta_2_model=theta_1-(np.pi-np.arcsin((lAB/lBC)*np.cos(theta_1)))

# Tracé de theta_2
plt.figure('Theta_2')
plt.plot(t,theta_2,t,theta_2_model)

# Calcul de lAC par la fermeture géométrique
lAC_model=(lBC*np.sin(theta_2)+lAB)/np.sin(theta_1);

# Tracé de lAC
plt.figure('lAC')
plt.plot(t,lAC,t,lAC_model)

dt=t[1:]-t[:-1]

# Calcul de omega_5
omega_1=(theta_1[1:]-theta_1[:-1])/dt

# Calcul de omega_6
omega_2=(theta_2[1:]-theta_2[:-1])/dt

omega_2_model=(lBC[:-1]/lAB)*omega_1/np.cos(theta_2[:-1]-theta_1[:-1])

# Tracé de omega_2
plt.figure('Omega_2')
plt.plot(t[:-1],omega_2,t[:-1],omega_2_model)

# Calcul de v
v=(lAC[1:]-lAC[:-1])/dt

v_model=-lBC[:-1]*omega_2*np.sin(theta_2[:-1]-theta_1[:-1])

plt.figure('v')
plt.plot(t[:-1],v,t[:-1],v_model)
